#define NOMINMAX

#include <windows.h>

#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>

#include <iostream>
#include <stdexcept>

#include "D3D11Core.hpp"
#include "D3D12Core.hpp"
#include "MfD3D11Nv12VideoReader.hpp"
#include "ToolTipPipelineD3D12.hpp"

#pragma comment(lib, "mf.lib")
#pragma comment(lib, "mfplat.lib")
#pragma comment(lib, "mfreadwrite.lib")
#pragma comment(lib, "mfuuid.lib")

namespace {

    void print_timing(
        const char* label,
        long long duration_ms,
        long long frame_count
    )
    {
        std::cout << label << ":\n";
        std::cout << "duration: " << duration_ms << " ms\n";

        if (duration_ms > 0) {
            std::cout
                << "fps     : "
                << frame_count / (static_cast<float>(duration_ms) / 1000.0f)
                << "\n";
        }
        else {
            std::cout << "fps     : inf / not measurable\n";
        }
    }

} // namespace

int wmain(int argc, wchar_t** argv)
{
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    if (argc < 2) {
        std::wcerr << L"Usage: dev_MfD3D11Nv12VideoReader.exe input.mp4 [model.onnx]\n";
        return 1;
    }

    HRESULT hr = CoInitializeEx(
        nullptr,
        COINIT_MULTITHREADED
    );

    if (FAILED(hr)) {
        std::cerr << "CoInitializeEx failed\n";
        return 1;
    }

    hr = MFStartup(MF_VERSION);

    if (FAILED(hr)) {
        std::cerr << "MFStartup failed\n";
        CoUninitialize();
        return 1;
    }

    int result = 0;

    long long bridge_copy_duration = 0;
    long long preprocess_duration = 0;
    long long ort_duration = 0;
    long long postprocess_duration = 0;
    long long tooltip_duration = 0;
    long long debug_save_duration = 0;
    long long total_duration = 0;
    long long frame_count = 0;

    try {
        D3D11Core d3d11;
        d3d11.initialize(
            false,  // enable_debug_layer
            true    // enable_multithread_protection
        );
        d3d11.print_adapter_info();

        D3D12Core d3d12;
        d3d12.initialize_with_adapter_LUID(
            d3d11.adapter_LUID(),
            true    // enable_debug_layer
        );
        d3d12.print_adapter_info();

        MfD3D11Nv12VideoReader video_reader(
            argv[1],
            d3d11
        );

        ToolTipPipelineD3D12::Config pipeline_config{};
        pipeline_config.model_path = (argc >= 3) ? argv[2] : L"model\\best_n_300.onnx";

        pipeline_config.input_width = 640;
        pipeline_config.input_height = 640;
        pipeline_config.limited_range_yuv = true;
        pipeline_config.pad_value = 114.0f / 255.0f;

        pipeline_config.num_attrs = 41;
        pipeline_config.num_candidates = 8400;
        pipeline_config.num_classes = 5;
        pipeline_config.num_mask_coeffs = 32;
        pipeline_config.mask_width = 160;
        pipeline_config.mask_height = 160;
        pipeline_config.max_candidates = 4096;
        pipeline_config.max_detections = 512;
        pipeline_config.conf_threshold = 0.25f;
        pipeline_config.iou_threshold = 0.45f;

        pipeline_config.target_class_id = 1;
        pipeline_config.mask_threshold = 0.5f;
        pipeline_config.min_area_pixels = 10;
        pipeline_config.end_region_ratio = 0.10f;
        pipeline_config.top_edge_ratio = 0.05f;
        pipeline_config.edge_reject_ratio = 0.02f;

        pipeline_config.enable_original_tip_debug_image_save = true;
        pipeline_config.original_tip_debug_save_interval = 250;
        pipeline_config.debug_output_directory = "img";
        pipeline_config.debug_score_threshold = 0.25f;
        pipeline_config.debug_mask_threshold = 0.5f;
        pipeline_config.debug_mask_alpha = 0.45f;
        pipeline_config.debug_draw_candidates = true;
        pipeline_config.debug_draw_axis = true;

        ToolTipPipelineD3D12 pipeline(
            d3d11,
            d3d12,
            pipeline_config
        );

        D3D11VideoFrame frame{};

        while (video_reader.read_next_frame(frame)) {
            ToolTipPipelineD3D12::PipelineFrameResult frame_result =
                pipeline.process_frame(frame);

            bridge_copy_duration += frame_result.timing.bridge_copy;
            preprocess_duration += frame_result.timing.preprocess;
            ort_duration += frame_result.timing.ort_inference;
            postprocess_duration += frame_result.timing.postprocess;
            tooltip_duration += frame_result.timing.tooltip_detect_and_readback;
            debug_save_duration += frame_result.timing.debug_save;
            total_duration += frame_result.timing.total;

            ++frame_count;

            // Example: access valid tips or per-frame timing here.
            // std::cout << "frame=" << frame_result.frame_index
            //           << " timing_frame=" << frame_result.timing.frame_index
            //           << " tips=" << frame_result.tips.size()
            //           << " total_ms=" << frame_result.timing.total << "\n";
        }

        std::wcout << L"Finished\n";
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        result = 1;
    }

    std::cout << "\n===== Timing summary =====\n";
    std::cout << "frames: " << frame_count << "\n";
    print_timing("Bridge copy", bridge_copy_duration, frame_count);
    print_timing("Preprocess", preprocess_duration, frame_count);
    print_timing("ORT/DML inference", ort_duration, frame_count);
    print_timing("Postprocess + tooltip GPU", postprocess_duration, frame_count);
    print_timing("Tooltip final readback", tooltip_duration, frame_count);
    print_timing("Debug save", debug_save_duration, frame_count);
    print_timing("Total", total_duration, frame_count);

    MFShutdown();
    CoUninitialize();

    return result;
}
